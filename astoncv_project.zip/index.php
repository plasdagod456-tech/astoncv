<?php include 'db.php'; ?>
<h2>All CVs</h2>
<form method="GET">
<input type="text" name="search" placeholder="Search">
<button>Search</button>
</form>

<?php
$query = "SELECT * FROM users JOIN cvs ON users.id=cvs.user_id";

if(isset($_GET['search'])){
    $search = "%".$_GET['search']."%";
    $stmt = $conn->prepare("SELECT * FROM users JOIN cvs ON users.id=cvs.user_id WHERE name LIKE ? OR programming_language LIKE ?");
    $stmt->bind_param("ss",$search,$search);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($query);
}

while($row = $result->fetch_assoc()){
    echo "<a href='view.php?id=".$row['id']."'>".$row['name']." - ".$row['programming_language']."</a><br>";
}
?>