CREATE DATABASE astoncv;
USE astoncv;

CREATE TABLE users (
id INT AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(100),
email VARCHAR(100) UNIQUE,
password VARCHAR(255)
);

CREATE TABLE cvs (
id INT AUTO_INCREMENT PRIMARY KEY,
user_id INT,
university VARCHAR(100),
programming_language VARCHAR(100),
profile TEXT,
links TEXT,
FOREIGN KEY (user_id) REFERENCES users(id)
);