<?php
$conn = new mysqli("localhost","root","","astoncv");
if($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
}
?>