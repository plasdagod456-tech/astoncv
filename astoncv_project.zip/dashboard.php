<?php
session_start();
include 'db.php';

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
}

if($_SERVER["REQUEST_METHOD"]=="POST"){
    $lang=$_POST['language'];
    $profile=$_POST['profile'];

    $stmt=$conn->prepare("INSERT INTO cvs(user_id,programming_language,profile) VALUES(?,?,?)");
    $stmt->bind_param("iss",$_SESSION['user_id'],$lang,$profile);
    $stmt->execute();

    echo "CV Updated!";
}
?>
<form method="POST">
<input name="language" placeholder="Programming Language" required>
<textarea name="profile" placeholder="Profile"></textarea>
<button>Save CV</button>
</form>
<a href="logout.php">Logout</a>