<?php
include 'db.php';
$id = $_GET['id'];

$stmt = $conn->prepare("SELECT * FROM users JOIN cvs ON users.id=cvs.user_id WHERE users.id=?");
$stmt->bind_param("i",$id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

echo "<h2>".$row['name']."</h2>";
echo "Email: ".$row['email']."<br>";
echo "University: ".$row['university']."<br>";
echo "Language: ".$row['programming_language']."<br>";
echo "Profile: ".$row['profile']."<br>";
echo "Links: ".$row['links']."<br>";
?>